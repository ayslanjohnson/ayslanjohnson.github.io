﻿using System;
using System.ComponentModel.DataAnnotations;

namespace PhDPoCServiceBusApi2.Model
{
    public class Payload
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public int Goals { get; set; }

        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [DataType(DataType.Date)]
        public DateTime Created { get; set; }
    }
}
