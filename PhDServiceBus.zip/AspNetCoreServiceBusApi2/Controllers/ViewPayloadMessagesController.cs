﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PhDPoCServiceBusApi2.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;

namespace PhDPoCServiceBusApi2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("All")]
    public class ViewPayloadMessagesController : Controller
    {
        private readonly PayloadContext _context;

        public ViewPayloadMessagesController(PayloadContext context)
        {
            _context = context;
        }

        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public ActionResult<List<Payload>> Get()
        {
            return Ok(_context.Payloads.ToList());
        }

        [HttpGet("{name}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public ActionResult<Payload> Get(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                return BadRequest();
            }

            var result = _context.Payloads.FirstOrDefault(d => d.Name == name);

            if (result == null)
            {
                return NotFound();
            }

            return Ok(result);
        }
    }
}
