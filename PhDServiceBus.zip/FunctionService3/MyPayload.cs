﻿namespace FunctionService3
{
    public class MyPayload
    {
        public string Name { get; set; }
        public int Goals { get; set; }
        public bool Delete { get; set; }
    }
}
