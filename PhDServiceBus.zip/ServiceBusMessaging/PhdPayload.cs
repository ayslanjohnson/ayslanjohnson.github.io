﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ServiceBusMessaging
{
    public class PhdPayload
    {
        public string Name { get; set; }
        public int Goals { get; set; }
        public bool Delete { get; set; }
    }
}
