﻿using Microsoft.Azure.ServiceBus;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System.Text;
using System.Threading.Tasks;

namespace ServiceBusMessaging
{
    public class ServiceBusSender
    {
        private readonly QueueClient _queueClient;
        private readonly IConfiguration _configuration;

        public ServiceBusSender(IConfiguration configuration)
        {
            _configuration = configuration;
            string queueName = _configuration.GetSection("ServiceBus").GetSection("Queue").GetSection("Name").Value;
            string connectionString = _configuration.GetSection("ServiceBus").GetSection("ConnectionString").Value;

            _queueClient = new QueueClient(connectionString, queueName);
        }
        
        public async Task SendMessage(PhdPayload payload)
        {
            string data = JsonConvert.SerializeObject(payload);
            Message message = new Message(Encoding.UTF8.GetBytes(data));

            await _queueClient.SendAsync(message);
        }
    }
}
